# SBSA fraud service - complete code: how to apply it

Unzip next to `build.gradle` (the inner `sbsa-fraud` folder) so `src/`, `scripts/` and
`lombok.config` land in the right places. Apply it as **three pull requests**, one per
feature, so the history shows the work in stages (WA0103.02 / WA0103.03).

## One-time changes (in PR 1)

**build.gradle** - add to `dependencies { }` (Spring Boot manages the version):

    compileOnly 'org.projectlombok:lombok'
    annotationProcessor 'org.projectlombok:lombok'
    testCompileOnly 'org.projectlombok:lombok'
    testAnnotationProcessor 'org.projectlombok:lombok'

**application.yml** - under `spring.jpa.properties.hibernate` add `type`:

    spring:
      jpa:
        properties:
          hibernate:
            jdbc:
              time_zone: UTC
            type:
              preferred_instant_jdbc_type: TIMESTAMP

**IntelliJ** - Settings > Build, Execution, Deployment > Compiler > Annotation Processors >
tick *Enable annotation processing*, then reload Gradle.

## PR 1 - `feature/domain-model`  (Jira: domain model task)
Files: `lombok.config`, `src/main/java/.../domain/**`, `src/main/java/.../repository/**`
Check: `bootRun` starts (Hibernate validates all 8 entities against MySQL).
Commit: `feat: add domain model and repositories`

## PR 2 - `feature/fraud-engine`  (Jira: US-03, US-06)
Files: `src/main/java/.../fraud/**`, `src/test/java/.../domain/TestData.java`,
`src/test/java/.../fraud/**`
Check: `gradlew test --tests "*fraud*"`
Commit: `feat: add fraud engine and velocity rule`

## PR 3 - `feature/transaction-api`  (Jira: US-01, US-02, US-04, US-05, US-07)
Files: everything else - `config/`, `service/`, `web/`, the remaining tests, `scripts/`
Check: `gradlew test`, then `bootRun` and `scripts\api-smoke-test.ps1`
Commit: `feat: add transaction API with alerts and decision log`

Each PR: branch from `develop`, push, open the PR into `develop`, merge, move the Jira
stories to Done.

## Release 1.0.0 (Q10)
1. Branch `release/1.0.0` from `develop`; in `build.gradle` set `version = '1.0.0'`.
2. PR `release/1.0.0` into **main**, merge, then tag: `git tag v1.0.0` and `git push origin v1.0.0`.
3. `gradlew publish` - the JAR goes to Nexus **maven-releases** and can never be overwritten.
4. Back on `develop`, set `version = '1.0.1-SNAPSHOT'`.

## Tests

| Run | What | Needs |
| --- | --- | --- |
| `gradlew test` | 45 automated tests (unit, controller, MySQL integration) | MySQL running, DB_USERNAME / DB_PASSWORD set |
| `scripts\api-smoke-test.ps1` | 16 HTTP cases, TC-01 to TC-24, against the running app | `bootRun` running |
| `scripts\latency-test.ps1 -Count 200` | NFR-01: p95 decision time | `bootRun` running |

Test report: `build\reports\tests\test\index.html`.
Run scripts with: `powershell -ExecutionPolicy Bypass -File scripts\api-smoke-test.ps1`

## API

    POST /api/transactions           submit; 201 + decision, or 400 / 409 {code, message}
    GET  /api/transactions/{ref}     status and alerts; 404 if unknown

Example body:

    {"transactionRef":"TX-0001","accountNumber":"4128728463","amount":50.00,
     "channel":"ATM","transactionType":"POS Purchase","city":"Durban",
     "timestamp":"2026-10-27T09:00:00Z"}
